df.groupby(['Module']).agg({
  'Mark': 'mean',
  'W_Mark': 'mean',
  'M_Mark': 'mean'
}).reset_index()