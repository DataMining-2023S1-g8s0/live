df = pd.read_csv('data/marks.csv', sep=',')
df['W_Mark'] = df.Weight * df.Mark // 100
df['M_Mark'] = df.groupby(['Student','Module'])[ ['W_Mark'] ].transform(sum)
print(df.shape)
df