df['AssessType'] = np.where(df['Deliverable'] == 'Exam', 'Exam', 'Practical')
df