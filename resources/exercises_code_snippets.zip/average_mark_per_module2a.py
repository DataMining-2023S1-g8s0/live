df.groupby(['Module']).agg(
  avgMark=("Mark", "mean"),
  avgW_Mark=("W_Mark", "mean"),
  avgM_Mark=("M_Mark", "mean")
).reset_index()